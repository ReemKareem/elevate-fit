# ElevateFit 🏃‍♂️⚡

Egypt's premium health platform — React + Express + SQLite.

## 📁 Project Structure

```
elevatefit/
├── frontend/          # React + Vite app
│   └── src/
│       ├── pages/      # All 9 pages
│       ├── components/ # Navbar, Footer, Toast
│       └── context/    # Auth state
└── backend/           # Express + SQLite API
    └── server.js
```

## 🚀 How to Run (VS Code)

### Option A — One command (recommended)

1. Open the `elevatefit` folder in VS Code
2. Open a terminal (`` Ctrl+` ``)
3. Run:
   ```bash
   npm run install:all
   npm run dev
   ```
4. Open **http://localhost:5173** in your browser 🎉

   (Backend runs on port 3001 automatically alongside it)

### Option B — Run separately (2 terminals)

**Terminal 1 — Backend:**
```bash
cd backend
npm install
npm start
```

**Terminal 2 — Frontend:**
```bash
cd frontend
npm install
npm run dev
```

Then open **http://localhost:5173**

## ✅ Requirements

- Node.js 18+ installed ([download here](https://nodejs.org))
- That's it — SQLite database is created automatically on first run, no extra setup needed.

## 🗂️ Pages Included

| Page | Route | Protected? |
|---|---|---|
| Home | `/` | No |
| Awareness (BMI calculator) | `/awareness` | No |
| Exercises (with video demos) | `/exercises` | No |
| Diet Plan (calorie calculator) | `/diet` | No |
| Progress Tracker | `/progress` | Yes 🔒 |
| Dashboard | `/dashboard` | Yes 🔒 |
| Transformations | `/transformation` | No |
| Contact Us | `/contact` | No |
| Profile | `/profile` | Yes 🔒 |
| Login / Register | `/login` | No |

## 🔧 Tech Stack

- **Frontend:** React 18, React Router, Vite (no Tailwind — pure CSS variables design system)
- **Backend:** Express, better-sqlite3, bcryptjs (password hashing), JSON Web Tokens
- **Database:** SQLite (file-based, zero config — `backend/elevatefit.db` is created automatically)

## 🔐 How Auth Works

- Register/Login creates a real user row in SQLite with a hashed password
- A JWT token is issued and stored in `localStorage`
- Protected pages (Progress, Dashboard, Profile) check `useAuth()` and show a "please log in" screen if there's no user
- Progress logs (weight, water, steps, BMI) are saved per-user in the database and persist across refreshes

## 📝 Notes

- The exercise video modal embeds real YouTube videos
- The BMI calculator and calorie calculator are fully functional with live calculations
- All design (colors, fonts, spacing) matches the original Lovable design — dark theme with lime green (`#c8f500`) accent
- To reset the database, just delete `backend/elevatefit.db` and restart the server

---

Built with ⚡ for Egypt's health journey.
