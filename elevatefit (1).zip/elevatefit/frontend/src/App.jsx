import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { Toast } from './components/Toast'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import Awareness from './pages/Awareness'
import Exercises from './pages/Exercises'
import Diet from './pages/Diet'
import Progress from './pages/Progress'
import Dashboard from './pages/Dashboard'
import Transformation from './pages/Transformation'
import Contact from './pages/Contact'
import Profile from './pages/Profile'
import Login from './pages/Login'
import './index.css'

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/awareness" element={<Awareness />} />
          <Route path="/exercises" element={<Exercises />} />
          <Route path="/diet" element={<Diet />} />
          <Route path="/progress" element={<Progress />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/transformation" element={<Transformation />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/login" element={<Login />} />
        </Routes>
        <Toast />
      </BrowserRouter>
    </AuthProvider>
  )
}
