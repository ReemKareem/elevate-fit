import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth, authHeader } from '../context/AuthContext'
import { showToast } from '../components/Toast'
import Footer from '../components/Footer'

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

export default function Progress() {
  const { user } = useAuth()
  const [logs, setLogs] = useState([])
  const [weight, setWeight] = useState('')
  const [water, setWater] = useState('')
  const [steps, setSteps] = useState('')
  const [bmi, setBmi] = useState('')

  useEffect(() => {
    if (user) fetchLogs()
  }, [user])

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/progress', { headers: authHeader() })
      if (res.ok) {
        const data = await res.json()
        setLogs(data)
      }
    } catch {}
  }

  const submit = async () => {
    if (!weight && !water && !steps) return
    try {
      await fetch('/api/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeader() },
        body: JSON.stringify({ weight: +weight || null, water: +water || null, steps: +steps || null, bmi: +bmi || null })
      })
      showToast('Entry logged! ✓')
      setWeight(''); setWater(''); setSteps(''); setBmi('')
      fetchLogs()
    } catch { showToast('Failed to log entry') }
  }

  if (!user) return (
    <div>
      <div className="page-wrap">
        <div className="container">
          <div className="protected-msg">
            <div className="protected-box">
              <div className="protected-icon">🔒</div>
              <h2>Login to track your progress</h2>
              <p>Your weight history, badges, and daily trackers stay synced when you sign in.</p>
              <Link to="/login" className="btn btn-primary btn-lg">Log in / Sign up</Link>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )

  const latestWeight = logs.find(l => l.weight)?.weight
  const latestBMI = logs.find(l => l.bmi)?.bmi
  const todayWater = logs[0]?.water || 0
  const todaySteps = logs[0]?.steps || 0
  const weightHistory = logs.filter(l => l.weight).slice(0, 7).reverse()
  const maxW = weightHistory.length ? Math.max(...weightHistory.map(l => l.weight)) : 100

  return (
    <div>
      <div className="page-wrap">
        <div className="container">
          <div className="page-hero" style={{ textAlign: 'left' }}>
            <h1>Your <span className="accent">Progress</span></h1>
            <p>Track weight, BMI, water intake & daily steps.</p>
          </div>

          {/* Metric Cards */}
          <div className="grid-4" style={{ marginBottom: 24 }}>
            {[
              { icon: '⚖️', label: 'Current Weight', value: latestWeight ? `${latestWeight} kg` : '—', sub: `Goal: ${user.target_weight || '—'} kg` },
              { icon: '📊', label: 'Latest BMI', value: latestBMI ? latestBMI : '—', sub: 'Normal: 18.5–24.9' },
              { icon: '💧', label: 'Water Today', value: `${todayWater} cups`, sub: 'Goal: 8 cups' },
              { icon: '👟', label: 'Steps Today', value: todaySteps.toLocaleString(), sub: 'Goal: 10,000' },
            ].map(m => (
              <div key={m.label} className="card">
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                  <div className="icon-box" style={{ width: 36, height: 36, fontSize: 16 }}>{m.icon}</div>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>{m.label}</span>
                </div>
                <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent)', lineHeight: 1 }}>{m.value}</div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-3)', marginTop: 4 }}>{m.sub}</div>
              </div>
            ))}
          </div>

          {/* Weight Chart */}
          {weightHistory.length > 0 && (
            <div className="card" style={{ marginBottom: 24 }}>
              <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: 20 }}>Weight History</h3>
              <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, height: 120 }}>
                {weightHistory.map((l, i) => {
                  const h = Math.max(20, ((l.weight / maxW) * 100))
                  const isLast = i === weightHistory.length - 1
                  return (
                    <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, height: '100%', justifyContent: 'flex-end' }}>
                      <span style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>{l.weight}kg</span>
                      <div style={{ width: '100%', height: `${h}%`, background: isLast ? 'var(--accent)' : 'rgba(200,245,0,0.15)', borderRadius: '4px 4px 0 0', transition: 'all 0.3s' }} />
                      <span style={{ fontSize: '0.65rem', color: 'var(--text-3)' }}>{new Date(l.created_at).toLocaleDateString('en', { month: 'short', day: 'numeric' })}</span>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* Log Form */}
          <div className="card" style={{ marginBottom: 80 }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: 20 }}>Log Today's Metrics</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 16 }}>
              {[
                { label: 'Weight (kg)', placeholder: '75', value: weight, setter: setWeight },
                { label: 'BMI', placeholder: '22.5', value: bmi, setter: setBmi },
                { label: 'Water (cups)', placeholder: '8', value: water, setter: setWater },
                { label: 'Steps', placeholder: '10000', value: steps, setter: setSteps },
              ].map(f => (
                <div key={f.label} className="form-group">
                  <label className="form-label">{f.label}</label>
                  <input className="form-input" type="number" placeholder={f.placeholder} value={f.value} onChange={e => f.setter(e.target.value)} />
                </div>
              ))}
            </div>
            <button onClick={submit} className="btn btn-primary">+ Log Entry</button>
          </div>

          {/* Recent Activity */}
          <div className="card" style={{ marginBottom: 80 }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: 16 }}>Recent Activity</h3>
            {logs.length === 0 ? (
              <p style={{ fontSize: '0.88rem', color: 'var(--text-2)' }}>No entries yet. <Link to="#" onClick={() => document.querySelector('.form-input')?.focus()} style={{ color: 'var(--accent)', fontWeight: 600 }}>Log your first →</Link></p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {logs.slice(0, 5).map((l, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, fontSize: '0.85rem' }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', flexShrink: 0 }} />
                    <span style={{ color: 'var(--text-2)' }}>
                      {[l.weight && `Weight: ${l.weight}kg`, l.bmi && `BMI: ${l.bmi}`, l.water && `Water: ${l.water} cups`, l.steps && `Steps: ${l.steps.toLocaleString()}`].filter(Boolean).join(' · ')}
                    </span>
                    <span style={{ fontSize: '0.78rem', color: 'var(--text-3)', marginLeft: 'auto' }}>{new Date(l.created_at).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
