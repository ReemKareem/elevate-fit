import { useState } from 'react'
import Footer from '../components/Footer'

const meals = {
  Breakfast: {
    time: '7:00 AM',
    items: [
      { name: 'Ful Medames (1 cup)', kcal: 220, p: 14, c: 32, f: 4 },
      { name: 'Whole Wheat Bread (1)', kcal: 130, p: 5, c: 25, f: 2 },
      { name: 'Tomato + Cucumber Salad', kcal: 40, p: 2, c: 8, f: 0 },
    ],
    snack: { time: '10:00 AM', label: 'Mid-Morning Snack', items: [
      { name: 'Greek Yogurt + Honey', kcal: 160, p: 12, c: 18, f: 4 },
      { name: 'Almonds (10)', kcal: 70, p: 3, c: 2, f: 6 },
    ]}
  },
  Lunch: {
    time: '1:00 PM',
    items: [
      { name: 'Grilled Chicken Breast (150g)', kcal: 248, p: 46, c: 0, f: 5 },
      { name: 'Brown Rice (1 cup)', kcal: 216, p: 5, c: 45, f: 2 },
      { name: 'Mixed Vegetable Salad', kcal: 60, p: 2, c: 12, f: 1 },
      { name: 'Olive Oil Dressing (1 tbsp)', kcal: 120, p: 0, c: 0, f: 14 },
    ],
  },
  Dinner: {
    time: '7:00 PM',
    items: [
      { name: 'Grilled Fish (150g)', kcal: 180, p: 35, c: 0, f: 4 },
      { name: 'Molokhia with Baladi Bread', kcal: 200, p: 8, c: 36, f: 3 },
      { name: 'Cucumber + Tomato', kcal: 35, p: 1, c: 7, f: 0 },
    ],
  },
  Snacks: {
    time: 'Throughout Day',
    items: [
      { name: 'Apple or Banana', kcal: 95, p: 1, c: 25, f: 0 },
      { name: 'Karkadeh (unsweetened)', kcal: 5, p: 0, c: 1, f: 0 },
      { name: 'Mixed Nuts (small handful)', kcal: 180, p: 5, c: 6, f: 16 },
    ],
  },
}

const avoidFoods = ['Sugary drinks (Cola, juices)', 'White bread (Aish Shamy refined)', "Deep fried foods (Ta'meya in excess)", 'Konafa, Basbousa daily', 'Processed meats (sausages)', 'Sweetened tea & coffee']
const eatFoods = ['Ful Medames & lentils', 'Whole wheat baladi bread', 'Grilled chicken & fish', 'Olive oil, nuts, avocado', 'Fresh fruits & vegetables', 'Karkadeh, green tea unsweetened']

const activityMult = { Sedentary: 1.2, Light: 1.375, Moderate: 1.55, Active: 1.725, 'Very Active': 1.9 }

export default function Diet() {
  const [tab, setTab] = useState('Breakfast')
  const [age, setAge] = useState(30)
  const [weight, setWeight] = useState(75)
  const [height, setHeight] = useState(170)
  const [activity, setActivity] = useState('Moderate')
  const [gender, setGender] = useState('male')

  const bmr = gender === 'male'
    ? 10 * weight + 6.25 * height - 5 * age + 5
    : 10 * weight + 6.25 * height - 5 * age - 161
  const tdee = Math.round(bmr * activityMult[activity])

  const mealData = meals[tab]

  return (
    <div>
      <div className="page-wrap">
        <div className="container">
          <div className="page-hero">
            <h1>Eat <span className="accent">Egyptian</span>, eat smart</h1>
            <p>Traditional foods, modern macros.</p>
          </div>

          {/* Calorie Calculator */}
          <div className="card" style={{ marginBottom: 56, padding: 36 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 6 }}>
              <span style={{ fontSize: 22 }}>🔥</span>
              <div>
                <h2 style={{ fontSize: '1.3rem', fontWeight: 800 }}>Daily Calorie Calculator</h2>
                <p style={{ color: 'var(--text-2)', fontSize: '0.875rem' }}>Mifflin-St Jeor formula adjusted by activity level.</p>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, margin: '24px 0' }}>
              {[
                { label: 'Age', value: age, setter: setAge, min: 15, max: 80 },
                { label: 'Weight (kg)', value: weight, setter: setWeight, min: 30, max: 200 },
                { label: 'Height (cm)', value: height, setter: setHeight, min: 140, max: 220 },
              ].map(f => (
                <div key={f.label} className="form-group">
                  <label className="form-label">{f.label}</label>
                  <input type="number" className="form-input" value={f.value} min={f.min} max={f.max}
                    onChange={e => f.setter(+e.target.value)} />
                </div>
              ))}
              <div className="form-group">
                <label className="form-label">Activity</label>
                <select className="form-input form-select" value={activity} onChange={e => setActivity(e.target.value)}>
                  {Object.keys(activityMult).map(a => <option key={a}>{a}</option>)}
                </select>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 16, marginBottom: 24 }}>
              {['male', 'female'].map(g => (
                <button key={g} onClick={() => setGender(g)} style={{ padding: '8px 20px', borderRadius: 999, fontWeight: 600, fontSize: '0.875rem', cursor: 'pointer', border: '1px solid', transition: 'all 0.2s', background: gender === g ? 'var(--accent)' : 'transparent', color: gender === g ? '#000' : 'var(--text-2)', borderColor: gender === g ? 'var(--accent)' : 'var(--border)', fontFamily: 'var(--font)' }}>
                  {g.charAt(0).toUpperCase() + g.slice(1)}
                </button>
              ))}
            </div>

            <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: '28px 24px', textAlign: 'center' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-3)', letterSpacing: 2, marginBottom: 8, fontWeight: 600 }}>TARGET DAILY CALORIES</div>
              <div style={{ fontSize: '3.5rem', fontWeight: 900, color: 'var(--accent)', lineHeight: 1 }}>{tdee}</div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-2)', marginTop: 4 }}>kcal / day</div>
            </div>
          </div>

          {/* Sample Menu */}
          <div style={{ marginBottom: 56 }}>
            <h2 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: 20 }}>Sample Daily Menu</h2>

            {/* Tabs */}
            <div style={{ display: 'flex', gap: 8, borderBottom: '1px solid var(--border)', marginBottom: 28 }}>
              {Object.keys(meals).map(t => (
                <button key={t} onClick={() => setTab(t)} style={{ padding: '10px 20px', fontSize: '0.875rem', fontWeight: 600, background: 'transparent', border: 'none', cursor: 'pointer', color: tab === t ? 'var(--accent)' : 'var(--text-2)', borderBottom: `2px solid ${tab === t ? 'var(--accent)' : 'transparent'}`, marginBottom: -1, transition: 'all 0.2s', fontFamily: 'var(--font)' }}>
                  {t}
                </button>
              ))}
            </div>

            {/* Meal Items */}
            {[{ time: mealData.time, label: tab, items: mealData.items }, ...(mealData.snack ? [mealData.snack] : [])].map(section => (
              <div key={section.label} className="card" style={{ marginBottom: 16 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
                  <span style={{ background: 'rgba(200,245,0,0.12)', color: 'var(--accent)', fontSize: '0.75rem', fontWeight: 700, padding: '4px 12px', borderRadius: 999 }}>🕐 {section.time}</span>
                  <span style={{ fontWeight: 700 }}>{section.label}</span>
                </div>
                {section.items.map(item => (
                  <div key={item.name} style={{ display: 'flex', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid var(--border)', fontSize: '0.88rem' }}>
                    <span style={{ flex: 1 }}>{item.name}</span>
                    <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
                      <span style={{ color: 'var(--accent)', fontWeight: 700 }}>{item.kcal} kcal</span>
                      <span style={{ color: 'var(--text-3)', fontSize: '0.8rem' }}>P {item.p}g</span>
                      <span style={{ color: 'var(--text-3)', fontSize: '0.8rem' }}>C {item.c}g</span>
                      <span style={{ color: 'var(--text-3)', fontSize: '0.8rem' }}>F {item.f}g</span>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>

          {/* Foods to Avoid / Eat */}
          <div className="grid-2" style={{ marginBottom: 80 }}>
            <div className="card" style={{ borderColor: 'rgba(239,68,68,0.3)' }}>
              <h3 style={{ fontWeight: 700, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ color: '#ef4444' }}>✗</span> Foods to Avoid
              </h3>
              <ul style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {avoidFoods.map(f => (
                  <li key={f} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.875rem', color: 'var(--text-2)' }}>
                    <span style={{ color: '#ef4444', fontWeight: 700 }}>✗</span>{f}
                  </li>
                ))}
              </ul>
            </div>
            <div className="card" style={{ borderColor: 'rgba(34,197,94,0.3)' }}>
              <h3 style={{ fontWeight: 700, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ color: '#22c55e' }}>✓</span> Foods to Eat
              </h3>
              <ul style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {eatFoods.map(f => (
                  <li key={f} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.875rem', color: 'var(--text-2)' }}>
                    <span style={{ color: '#22c55e', fontWeight: 700 }}>✓</span>{f}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
