import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth, authHeader } from '../context/AuthContext'
import { showToast } from '../components/Toast'
import Footer from '../components/Footer'

export default function Profile() {
  const { user, updateUser } = useAuth()
  const [form, setForm] = useState({ name: '', phone: '', gender: 'Male', location: 'Cairo, Egypt', height: '', current_weight: '', target_weight: '', activity_level: 'Moderate' })

  useEffect(() => {
    if (user) setForm({
      name: user.name || user.username || '',
      phone: user.phone || '',
      gender: user.gender || 'Male',
      location: user.location || 'Cairo, Egypt',
      height: user.height || '',
      current_weight: user.current_weight || '',
      target_weight: user.target_weight || '',
      activity_level: user.activity_level || 'Moderate',
    })
  }, [user])

  const save = async () => {
    try {
      const res = await fetch('/api/user/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...authHeader() },
        body: JSON.stringify(form)
      })
      if (res.ok) {
        updateUser(form)
        showToast('Profile saved! ✓')
      }
    } catch { showToast('Saved locally ✓'); updateUser(form) }
  }

  const initials = (form.name || user?.username || 'U').slice(0, 2).toUpperCase()

  const lossGoal = form.current_weight && form.target_weight && form.current_weight > form.target_weight
    ? Math.round(((form.current_weight - form.target_weight) / form.current_weight) * 100)
    : 0

  if (!user) return (
    <div>
      <div className="page-wrap">
        <div className="container">
          <div className="protected-msg">
            <div className="protected-box">
              <div className="protected-icon">👤</div>
              <h2>Sign in to view your profile</h2>
              <Link to="/login" className="btn btn-primary btn-lg" style={{ marginTop: 8 }}>Log in</Link>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )

  return (
    <div>
      <div className="page-wrap">
        <div className="container" style={{ paddingTop: 40, paddingBottom: 80 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 24, alignItems: 'start' }}>

            {/* Left Sidebar */}
            <div>
              <div className="card" style={{ textAlign: 'center', marginBottom: 16 }}>
                <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, fontWeight: 900, color: '#000', margin: '0 auto 12px' }}>{initials}</div>
                <h2 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: 4 }}>{form.name || user.username}</h2>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-2)' }}>{user.email}</p>

                {/* Progress Rings */}
                <div style={{ display: 'flex', justifyContent: 'center', gap: 24, marginTop: 20 }}>
                  {[
                    { label: 'Loss goal', pct: lossGoal, color: lossGoal > 0 ? 'var(--accent)' : 'var(--border)' },
                    { label: 'Health', pct: 81, color: 'var(--accent)' },
                  ].map(r => (
                    <div key={r.label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                      <svg width="56" height="56" viewBox="0 0 56 56">
                        <circle cx="28" cy="28" r="22" fill="none" stroke="var(--border)" strokeWidth="4" />
                        <circle cx="28" cy="28" r="22" fill="none" stroke={r.color} strokeWidth="4"
                          strokeDasharray={`${(r.pct / 100) * 138} 138`} strokeDashoffset="34.5"
                          strokeLinecap="round" transform="rotate(-90 28 28)" />
                        <text x="28" y="33" textAnchor="middle" fill="white" fontSize="11" fontWeight="700">{r.pct}%</text>
                      </svg>
                      <span style={{ fontSize: '0.72rem', color: 'var(--text-2)' }}>{r.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Content */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {/* Personal Info */}
              <div className="card">
                <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: 20 }}>Personal Information</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
                  <div className="form-group">
                    <label className="form-label">Name</label>
                    <input className="form-input" value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Ahmed Hassan" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Email</label>
                    <input className="form-input" value={user.email} disabled style={{ opacity: 0.6 }} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Phone</label>
                    <input className="form-input" value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} placeholder="+20 100 123 4567" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Gender</label>
                    <select className="form-input form-select" value={form.gender} onChange={e => setForm({...form, gender: e.target.value})}>
                      {['Male', 'Female', 'Prefer not to say'].map(g => <option key={g}>{g}</option>)}
                    </select>
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Location</label>
                  <input className="form-input" value={form.location} onChange={e => setForm({...form, location: e.target.value})} placeholder="Cairo, Egypt" />
                </div>
              </div>

              {/* Health Details */}
              <div className="card">
                <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: 20 }}>Health Details</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                  {[
                    { label: 'Height (cm)', key: 'height', placeholder: '175' },
                    { label: 'Current Weight (kg)', key: 'current_weight', placeholder: '82' },
                    { label: 'Target Weight (kg)', key: 'target_weight', placeholder: '72' },
                  ].map(f => (
                    <div key={f.key} className="form-group">
                      <label className="form-label">{f.label}</label>
                      <input className="form-input" type="number" placeholder={f.placeholder} value={form[f.key]} onChange={e => setForm({...form, [f.key]: e.target.value})} />
                    </div>
                  ))}
                  <div className="form-group">
                    <label className="form-label">Activity Level</label>
                    <select className="form-input form-select" value={form.activity_level} onChange={e => setForm({...form, activity_level: e.target.value})}>
                      {['Sedentary', 'Light', 'Moderate', 'Active', 'Very Active'].map(a => <option key={a}>{a}</option>)}
                    </select>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 12 }}>
                <button onClick={() => { if(user) setForm({ name: user.name || user.username || '', phone: user.phone || '', gender: user.gender || 'Male', location: user.location || 'Cairo, Egypt', height: user.height || '', current_weight: user.current_weight || '', target_weight: user.target_weight || '', activity_level: user.activity_level || 'Moderate' }) }} className="btn btn-outline">Cancel</button>
                <button onClick={save} className="btn btn-primary">Save changes</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
