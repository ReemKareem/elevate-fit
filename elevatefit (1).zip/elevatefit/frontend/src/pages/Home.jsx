import { Link } from 'react-router-dom'
import Footer from '../components/Footer'

const stats = [
  { value: '39.5%', label: 'Obesity Rate', desc: 'Adults in Egypt classified as obese' },
  { value: '15.6%', label: 'Diabetes Prevalence', desc: 'Of the adult population is diabetic' },
  { value: '73%', label: 'Lifestyle Change Needed', desc: 'Could be prevented by diet & exercise' },
]

const features = [
  { icon: '🤖', label: 'AI Chatbot', desc: 'Personalized advice powered by Fit AI', badge: 'New', to: '/awareness' },
  { icon: '📈', label: 'Progress Tracker', desc: 'Log weight, BMI, water & activity', to: '/progress' },
  { icon: '🏆', label: 'Transformations', desc: 'Real success stories from Egypt', to: '/transformation' },
  { icon: '🥗', label: 'Diet Plans', desc: 'Egyptian-style meals with macros', to: '/diet' },
  { icon: '🏋️', label: 'Gym Workouts', desc: 'Beginner to advanced splits', to: '/exercises' },
  { icon: '🛡️', label: 'Admin Dashboard', desc: 'Full system overview & analytics', to: '/dashboard' },
]

const testimonials = [
  { stars: 5, text: 'Elevate Fit gave me the structure I never had. The Egyptian meal plans made it so easy to follow.', name: 'Mona A.', result: 'Lost 12kg' },
  { stars: 5, text: 'Tracking glucose alongside workouts changed everything. The chatbot is always there to help.', name: 'Karim H.', result: 'Pre-diabetic → Reversed' },
  { stars: 5, text: 'The gym splits and progress charts are pro level. Best fitness app in Egypt.', name: 'Sara M.', result: 'Gained 8kg muscle' },
]

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '120px 24px 60px', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: '-10%', left: '50%', transform: 'translateX(-50%)', width: 600, height: 600, background: 'radial-gradient(circle, rgba(200,245,0,0.07) 0%, transparent 70%)', pointerEvents: 'none' }} />

        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 14px', borderRadius: 999, border: '1px solid rgba(200,245,0,0.3)', background: 'rgba(200,245,0,0.06)', fontSize: '0.78rem', fontWeight: 600, color: 'var(--accent)', marginBottom: 28 }}>
          🌍 Health platform for Egypt
        </div>

        <h1 style={{ fontSize: 'clamp(2.8rem, 6vw, 5rem)', fontWeight: 900, lineHeight: 1.05, letterSpacing: '-2px', maxWidth: 820, marginBottom: 18 }}>
          Take control of your<br /><span className="accent">health journey</span>
        </h1>

        <p style={{ fontSize: '1.05rem', color: 'var(--text-2)', maxWidth: 520, marginBottom: 40, lineHeight: 1.7 }}>
          Personalized BMI tools, Egyptian-style diet plans, structured workouts and AI coaching — built for the way Egyptians actually live.
        </p>

        <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 80 }}>
          <Link to="/awareness" className="btn btn-primary btn-lg">🧮 Calculate BMI</Link>
          <Link to="/login" className="btn btn-outline btn-lg">Start your journey →</Link>
        </div>

        {/* Stats */}
        <div className="grid-3" style={{ maxWidth: 960, width: '100%' }}>
          {stats.map(s => (
            <div key={s.label} className="card card-hover">
              <div style={{ fontSize: '2.2rem', fontWeight: 800, color: 'var(--accent)', lineHeight: 1, marginBottom: 8 }}>{s.value}</div>
              <div style={{ fontSize: '0.95rem', fontWeight: 600, marginBottom: 4 }}>{s.label}</div>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-2)' }}>{s.desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Everything you need, <span className="accent">in one place</span></h2>
            <p className="section-sub">Six powerful tools designed for Egypt's health challenges.</p>
          </div>
          <div className="grid-3">
            {features.map(f => (
              <Link key={f.label} to={f.to} style={{ textDecoration: 'none' }}>
                <div className="card card-hover" style={{ position: 'relative', cursor: 'pointer', height: '100%' }}>
                  {f.badge && <span style={{ position: 'absolute', top: 16, right: 16, background: 'var(--accent)', color: '#000', fontSize: '0.7rem', fontWeight: 700, padding: '2px 10px', borderRadius: 999 }}>{f.badge}</span>}
                  <div className="icon-box" style={{ marginBottom: 14 }}>{f.icon}</div>
                  <div style={{ fontSize: '1rem', fontWeight: 700, marginBottom: 6 }}>{f.label}</div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--text-2)' }}>{f.desc}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Real stories, <span className="accent">real results</span></h2>
          </div>
          <div className="grid-3">
            {testimonials.map((t, i) => (
              <div key={i} className="card card-hover">
                <div className="stars">{'★'.repeat(t.stars)}</div>
                <p style={{ fontSize: '0.9rem', color: 'var(--text-2)', lineHeight: 1.65, margin: '14px 0 20px', fontStyle: 'italic' }}>"{t.text}"</p>
                <div style={{ fontSize: '0.9rem', fontWeight: 700 }}>{t.name}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--accent)', marginTop: 2 }}>{t.result}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="card" style={{ textAlign: 'center', padding: '72px 24px', borderRadius: 'var(--radius-xl)' }}>
            <h2 className="section-title">Ready to transform <span className="accent">your life?</span></h2>
            <p style={{ color: 'var(--text-2)', marginBottom: 32, fontSize: '0.95rem' }}>Join thousands of Egyptians taking control of their health with Elevate Fit.</p>
            <Link to="/login" className="btn btn-primary btn-lg">Get started free →</Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
