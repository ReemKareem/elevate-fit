import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth, authHeader } from '../context/AuthContext'
import { showToast } from '../components/Toast'
import Footer from '../components/Footer'

const tips = [
  'Drink water before each meal — cuts overeating by 13%.',
  'Walk 10 minutes after lunch — boosts metabolism significantly.',
  'Sleep 7–8 hours — poor sleep increases hunger hormones.',
  'Eat protein at breakfast — reduces cravings throughout the day.',
  'Replace white rice with brown rice — same taste, better blood sugar.',
]

export default function Dashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [logs, setLogs] = useState([])
  const [logModal, setLogModal] = useState(false)
  const [weight, setWeight] = useState('')
  const [water, setWater] = useState('')
  const [steps, setSteps] = useState('')
  const tip = tips[new Date().getDay() % tips.length]

  useEffect(() => {
    if (user) fetchLogs()
  }, [user])

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/progress', { headers: authHeader() })
      if (res.ok) setLogs(await res.json())
    } catch {}
  }

  const submitLog = async () => {
    try {
      await fetch('/api/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeader() },
        body: JSON.stringify({ weight: +weight || null, water: +water || null, steps: +steps || null })
      })
      showToast('Logged! ✓')
      setLogModal(false); setWeight(''); setWater(''); setSteps('')
      fetchLogs()
    } catch {}
  }

  if (!user) return (
    <div>
      <div className="page-wrap">
        <div className="container">
          <div className="protected-msg">
            <div className="protected-box">
              <div className="protected-icon">🔒</div>
              <h2>Sign in to view your dashboard</h2>
              <Link to="/login" className="btn btn-primary btn-lg" style={{ marginTop: 8 }}>Log in</Link>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )

  const today = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
  const latestLog = logs[0]

  const quickActions = [
    { label: 'Log today\'s weight', to: '/progress' },
    { label: 'See today\'s meals', to: '/diet' },
    { label: 'Start a workout', to: '/exercises' },
    { label: 'Check BMI', to: '/awareness' },
  ]

  return (
    <div>
      <div className="page-wrap">
        <div className="container">
          <div style={{ padding: '40px 0 32px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: '0.82rem', color: 'var(--text-2)', marginBottom: 8 }}>
                  📅 {today}
                </div>
                <h1 style={{ fontSize: 'clamp(1.6rem, 3vw, 2.2rem)', fontWeight: 900, letterSpacing: -1 }}>
                  Welcome back, <span className="accent">{user.username}</span>
                </h1>
              </div>
              <button onClick={() => setLogModal(true)} className="btn btn-primary">+ Log metric</button>
            </div>
          </div>

          {/* Metric Cards */}
          <div className="grid-4" style={{ marginBottom: 24 }}>
            {[
              { icon: '📉', label: 'Current Weight', value: latestLog?.weight ? `${latestLog.weight} kg` : '—', sub: `Goal: ${user.target_weight || '72'} kg` },
              { icon: '📊', label: 'Latest BMI', value: latestLog?.bmi ? latestLog.bmi : '—', sub: 'Normal: 18.5–24.9' },
              { icon: '💧', label: 'Water Today', value: latestLog?.water ? `${latestLog.water} cups` : '0 cups', sub: 'Goal: 8 cups' },
              { icon: '👟', label: 'Steps Today', value: latestLog?.steps ? latestLog.steps.toLocaleString() : '0', sub: 'Goal: 10,000' },
            ].map(m => (
              <div key={m.label} className="card">
                <div className="icon-box" style={{ width: 36, height: 36, fontSize: 16, marginBottom: 10 }}>{m.icon}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-2)', marginBottom: 4 }}>{m.label}</div>
                <div style={{ fontSize: '1.7rem', fontWeight: 800, lineHeight: 1 }}>{m.value}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-3)', marginTop: 4 }}>{m.sub}</div>
              </div>
            ))}
          </div>

          {/* Quick Actions + Daily Tip */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginBottom: 24 }}>
            <div className="card">
              <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: 16 }}>Quick actions</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                {quickActions.map(a => (
                  <Link key={a.label} to={a.to} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '13px 16px', background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border)', borderRadius: 10, fontSize: '0.875rem', color: 'var(--text)', textDecoration: 'none', transition: 'all 0.2s' }}
                    onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(200,245,0,0.3)'}
                    onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}>
                    {a.label} <span style={{ color: 'var(--text-3)' }}>›</span>
                  </Link>
                ))}
              </div>
            </div>
            <div className="card">
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                <span>💡</span><span style={{ fontSize: '0.95rem', fontWeight: 700 }}>Daily tip</span>
              </div>
              <p style={{ fontSize: '0.875rem', color: 'var(--text-2)', lineHeight: 1.6, marginBottom: 16 }}>{tip}</p>
              <div style={{ height: 3, background: 'var(--border)', borderRadius: 99 }}>
                <div style={{ height: '100%', width: `${((new Date().getDay() + 1) / 7) * 100}%`, background: 'var(--accent)', borderRadius: 99 }} />
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="card" style={{ marginBottom: 80 }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: 16 }}>Recent activity</h3>
            {logs.length === 0 ? (
              <p style={{ fontSize: '0.88rem', color: 'var(--text-2)' }}>
                No entries yet. <button onClick={() => setLogModal(true)} style={{ background: 'none', border: 'none', color: 'var(--accent)', fontWeight: 600, cursor: 'pointer', fontSize: '0.88rem', fontFamily: 'var(--font)' }}>Log your first →</button>
              </p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {logs.slice(0, 5).map((l, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.85rem' }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', flexShrink: 0 }} />
                    <span style={{ color: 'var(--text-2)' }}>
                      {[l.weight && `Weight: ${l.weight}kg`, l.water && `Water: ${l.water}c`, l.steps && `Steps: ${l.steps.toLocaleString()}`].filter(Boolean).join(' · ')}
                    </span>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-3)', marginLeft: 'auto' }}>{new Date(l.created_at).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Log Modal */}
      {logModal && (
        <div className="modal-overlay" onClick={() => setLogModal(false)}>
          <div className="modal" style={{ maxWidth: 420 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Log a metric</h3>
              <button className="modal-close" onClick={() => setLogModal(false)}>✕</button>
            </div>
            <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {[
                { label: 'Weight (kg)', placeholder: '75', value: weight, setter: setWeight },
                { label: 'Water (cups)', placeholder: '8', value: water, setter: setWater },
                { label: 'Steps', placeholder: '10000', value: steps, setter: setSteps },
              ].map(f => (
                <div key={f.label} className="form-group">
                  <label className="form-label">{f.label}</label>
                  <input className="form-input" type="number" placeholder={f.placeholder} value={f.value} onChange={e => f.setter(e.target.value)} />
                </div>
              ))}
              <button onClick={submitLog} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', padding: 14 }}>Save entry</button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  )
}
