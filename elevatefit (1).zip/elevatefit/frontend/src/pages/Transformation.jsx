import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { showToast } from '../components/Toast'
import Footer from '../components/Footer'

const stories = [
  { name: 'Mona', age: 34, category: 'weight-loss', duration: '8 months', before: '92 kg', after: '70 kg', beforeLabel: 'BEFORE', afterLabel: 'AFTER', beforeColor: '#ef4444', afterColor: '#c8f500', story: 'Cut soda and sugary tea, walked 8K steps daily, learned to cook lighter Egyptian meals.' },
  { name: 'Karim', age: 41, category: 'diabetes', duration: '6 months', before: 'HbA1c 8.4', after: 'HbA1c 5.7', beforeLabel: 'BEFORE', afterLabel: 'AFTER', beforeColor: '#ef4444', afterColor: '#c8f500', story: 'Switched to whole grains, daily 30-min walks, and intermittent fasting. Reversed pre-diabetes.' },
  { name: 'Sara', age: 27, category: 'muscle-gain', duration: '10 months', before: '52 kg', after: '60 kg', beforeLabel: 'BEFORE', afterLabel: 'AFTER', beforeColor: '#ef4444', afterColor: '#c8f500', story: '4-day gym split, high-protein diet (chicken, eggs, cottage cheese), tracked every set.' },
  { name: 'Yousef', age: 38, category: 'weight-loss', duration: '12 months', before: '108 kg', after: '82 kg', beforeLabel: 'BEFORE', afterLabel: 'AFTER', beforeColor: '#ef4444', afterColor: '#c8f500', story: 'Stopped late-night snacking, batch-cooked Sunday meals, joined a running club.' },
  { name: 'Nour', age: 29, category: 'muscle-gain', duration: '7 months', before: '58 kg', after: '65 kg', beforeLabel: 'BEFORE', afterLabel: 'AFTER', beforeColor: '#ef4444', afterColor: '#c8f500', story: 'Compound lifts 3x/week with steady creatine and protein. Strength tripled.' },
  { name: 'Hassan', age: 52, category: 'diabetes', duration: '14 months', before: 'Insulin daily', after: 'Off insulin', beforeLabel: 'BEFORE', afterLabel: 'AFTER', beforeColor: '#ef4444', afterColor: '#c8f500', story: 'Lost 18 kg, daily swimming, low-carb baladi diet. Doctor cleared insulin.' },
]

const filters = ['All', 'Weight Loss', 'Muscle Gain', 'Diabetes Management']
const filterMap = { 'All': null, 'Weight Loss': 'weight-loss', 'Muscle Gain': 'muscle-gain', 'Diabetes Management': 'diabetes' }

export default function Transformation() {
  const { user } = useAuth()
  const [active, setActive] = useState('All')
  const [submitModal, setSubmitModal] = useState(false)
  const [form, setForm] = useState({ name: '', story: '', result: '' })

  const filtered = active === 'All' ? stories : stories.filter(s => s.category === filterMap[active])

  const handleSubmit = () => {
    showToast('Story submitted! We\'ll review it soon 🙏')
    setSubmitModal(false)
    setForm({ name: '', story: '', result: '' })
  }

  return (
    <div>
      <div className="page-wrap">
        <div className="container">
          <div className="page-hero">
            <h1>Real <span className="accent">Transformations</span></h1>
            <p>Egyptians who took control. You're next.</p>
          </div>

          <div className="filter-bar" style={{ justifyContent: 'center', marginBottom: 40 }}>
            {filters.map(f => (
              <button key={f} className={`filter-btn ${active === f ? 'active' : ''}`} onClick={() => setActive(f)}>{f}</button>
            ))}
          </div>

          <div className="grid-2" style={{ marginBottom: 48 }}>
            {filtered.map((s, i) => (
              <div key={i} className="card card-hover">
                <div style={{ marginBottom: 12 }}>
                  <h3 style={{ fontSize: '1.05rem', fontWeight: 700 }}>{s.name}, {s.age}</h3>
                  <div style={{ fontSize: '0.8rem', color: 'var(--accent)', fontWeight: 600 }}>
                    {filters.find(f => filterMap[f] === s.category)} · {s.duration}
                  </div>
                </div>

                {/* Before / After */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 16 }}>
                  <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border)', borderRadius: 10, padding: '16px', textAlign: 'center' }}>
                    <div style={{ fontSize: '0.65rem', color: 'var(--text-3)', letterSpacing: 2, marginBottom: 6 }}>BEFORE</div>
                    <div style={{ fontSize: '1.3rem', fontWeight: 800, color: s.beforeColor }}>{s.before}</div>
                  </div>
                  <div style={{ background: 'rgba(200,245,0,0.05)', border: '1px solid rgba(200,245,0,0.2)', borderRadius: 10, padding: '16px', textAlign: 'center' }}>
                    <div style={{ fontSize: '0.65rem', color: 'var(--text-3)', letterSpacing: 2, marginBottom: 6 }}>AFTER</div>
                    <div style={{ fontSize: '1.3rem', fontWeight: 800, color: s.afterColor }}>{s.after}</div>
                  </div>
                </div>

                <p style={{ fontSize: '0.875rem', color: 'var(--text-2)', lineHeight: 1.65, marginBottom: 14 }}>{s.story}</p>
                <button onClick={() => showToast(`${s.name}'s full story coming soon!`)} style={{ background: 'none', border: 'none', color: 'var(--accent)', fontWeight: 600, fontSize: '0.875rem', cursor: 'pointer', padding: 0, fontFamily: 'var(--font)' }}>
                  Read story →
                </button>
              </div>
            ))}
          </div>

          {/* Share CTA */}
          <div className="card" style={{ textAlign: 'center', padding: '56px 24px', marginBottom: 80 }}>
            <div style={{ fontSize: 36, marginBottom: 16 }}>⬆️</div>
            <h2 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: 8 }}>Share your transformation</h2>
            <p style={{ color: 'var(--text-2)', marginBottom: 24, fontSize: '0.9rem' }}>Inspire others. Submit your before & after story.</p>
            <button onClick={() => user ? setSubmitModal(true) : showToast('Please log in to share your story')} className="btn btn-primary btn-lg">
              Submit your story
            </button>
          </div>
        </div>
      </div>

      {/* Submit Modal */}
      {submitModal && (
        <div className="modal-overlay" onClick={() => setSubmitModal(false)}>
          <div className="modal" style={{ maxWidth: 480 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Share your story</h3>
              <button className="modal-close" onClick={() => setSubmitModal(false)}>✕</button>
            </div>
            <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Your name</label>
                <input className="form-input" placeholder="e.g. Ahmed, 29" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
              </div>
              <div className="form-group">
                <label className="form-label">Your result</label>
                <input className="form-input" placeholder="e.g. Lost 15kg in 6 months" value={form.result} onChange={e => setForm({...form, result: e.target.value})} />
              </div>
              <div className="form-group">
                <label className="form-label">Your story</label>
                <textarea className="form-input" rows={4} placeholder="What changed? What did you do?" value={form.story} onChange={e => setForm({...form, story: e.target.value})} style={{ resize: 'vertical', minHeight: 100 }} />
              </div>
              <button onClick={handleSubmit} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', padding: 14 }}>Submit story</button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  )
}
