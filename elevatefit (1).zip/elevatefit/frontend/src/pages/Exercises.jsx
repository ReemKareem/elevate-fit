import { useState } from 'react'
import Footer from '../components/Footer'

const exercises = [
  { id: 1, name: 'Walking', duration: '30 min', kcal: '~150 kcal', tags: ['beginner', 'low'], muscle: 'cardio', icon: '🚶', ytId: 'njeZ29umqVE', desc: 'Low-impact cardio great for all fitness levels. Start at a comfortable pace and gradually increase.' },
  { id: 2, name: 'Bodyweight Squats', duration: '5 min', kcal: '~50 kcal', tags: ['beginner'], muscle: 'legs', icon: '🏋️', ytId: 'aclHkVaku9U', desc: 'Compound lower body movement targeting quads, hamstrings and glutes. Perfect for beginners.' },
  { id: 3, name: 'Chair Exercises', duration: '15 min', kcal: '~60 kcal', tags: ['beginner', 'low'], muscle: 'cardio', icon: '🪑', ytId: '6OZVHmKlMPs', desc: 'Seated workout perfect for beginners or those with mobility limitations.' },
  { id: 4, name: 'Swimming', duration: '30 min', kcal: '~250 kcal', tags: ['low', 'intermediate'], muscle: 'cardio', icon: '🏊', ytId: 'gh5mAtmeR3Y', desc: 'Full body low-impact workout that builds endurance and burns significant calories.' },
  { id: 5, name: 'Jogging', duration: '25 min', kcal: '~280 kcal', tags: ['intermediate'], muscle: 'cardio', icon: '🏃', ytId: 'kVnyY17VS9Y', desc: 'Cardiovascular exercise that improves heart health and burns fat effectively.' },
  { id: 6, name: 'Jump Rope', duration: '10 min', kcal: '~200 kcal', tags: ['intermediate'], muscle: 'cardio', icon: '🪢', ytId: 'FJmRQ5iTXKE', desc: 'High-intensity cardio that improves coordination and burns calories fast.' },
  { id: 7, name: 'Push-Ups', duration: '10 min', kcal: '~80 kcal', tags: ['intermediate', 'gym'], muscle: 'chest', icon: '💪', ytId: '0pkjOk0EiAk', desc: 'Classic upper body exercise targeting chest, shoulders and triceps.' },
  { id: 8, name: 'Dumbbell Rows', duration: '20 min', kcal: '~120 kcal', tags: ['beginner', 'intermediate'], muscle: 'back', icon: '🏋️', ytId: 'roCP26tFHew', desc: 'Back strengthening exercise that improves posture and builds muscle.' },
  { id: 9, name: 'Shoulder Press', duration: '15 min', kcal: '~90 kcal', tags: ['gym'], muscle: 'shoulders', icon: '🤸', ytId: 'qEwKCR5JCog', desc: 'Overhead pressing movement for shoulder development and strength.' },
  { id: 10, name: 'Treadmill', duration: '30 min', kcal: '~300 kcal', tags: ['gym', 'intermediate'], muscle: 'cardio', icon: '🏃', ytId: 'lO9-knDEmEo', desc: 'Controlled cardio training with adjustable speed and incline settings.' },
  { id: 11, name: 'Cycling', duration: '40 min', kcal: '~350 kcal', tags: ['intermediate', 'gym'], muscle: 'cardio', icon: '🚴', ytId: 'UGEpQ1vwq_4', desc: 'Low-impact cardio perfect for building lower body endurance.' },
]

const gymSplits = [
  { title: 'Chest Day', sets: '4×10', exercises: ['Bench Press', 'Incline Dumbbell Press', 'Chest Fly', 'Push Ups'] },
  { title: 'Leg Day', sets: '4×12', exercises: ['Barbell Squats', 'Leg Press', 'Lunges', 'Calf Raises'] },
  { title: 'Back & Biceps', sets: '4×10', exercises: ['Deadlift', 'Lat Pulldown', 'Barbell Row', 'Dumbbell Curls'] },
  { title: 'Shoulders & Triceps', sets: '4×10', exercises: ['Overhead Press', 'Lateral Raises', 'Tricep Dips', 'Skullcrushers'] },
]

const filters = ['All Exercises', 'Beginner', 'Low Impact', 'Intermediate', 'Gym Workouts']
const filterMap = { 'All Exercises': null, 'Beginner': 'beginner', 'Low Impact': 'low', 'Intermediate': 'intermediate', 'Gym Workouts': 'gym' }

export default function Exercises() {
  const [active, setActive] = useState('All Exercises')
  const [modal, setModal] = useState(null)

  const filtered = active === 'All Exercises'
    ? exercises
    : exercises.filter(e => e.tags.includes(filterMap[active]))

  return (
    <div>
      <div className="page-wrap">
        <div className="container">
          <div className="page-hero">
            <h1>Move <span className="accent">smarter</span></h1>
            <p>From your living room to the gym floor.</p>
          </div>

          {/* Filter */}
          <div className="filter-bar">
            {filters.map(f => (
              <button key={f} className={`filter-btn ${active === f ? 'active' : ''}`} onClick={() => setActive(f)}>{f}</button>
            ))}
          </div>

          {/* Exercise Cards */}
          <div className="grid-3" style={{ marginBottom: 64 }}>
            {filtered.map(ex => (
              <div key={ex.id} className="card card-hover" style={{ cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: 12 }} onClick={() => setModal(ex)}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div className="icon-box">{ex.icon}</div>
                  <span style={{ color: 'var(--text-3)', fontSize: 18 }}>›</span>
                </div>
                <div>
                  <h3 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: 4 }}>{ex.name}</h3>
                  <p style={{ fontSize: '0.82rem', color: 'var(--text-2)', marginBottom: 10 }}>{ex.duration} · {ex.kcal}</p>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {ex.tags.map(t => <span key={t} className={`tag tag-${t}`}>{t.charAt(0).toUpperCase() + t.slice(1)}</span>)}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Gym Splits */}
          <div style={{ marginBottom: 80 }}>
            <h2 style={{ fontSize: '1.6rem', fontWeight: 800, marginBottom: 6 }}>Gym Split <span className="accent">Programs</span></h2>
            <p style={{ color: 'var(--text-2)', marginBottom: 32 }}>4-day push/pull/legs structure. Track sets, reps, and tempo.</p>
            <div className="grid-4">
              {gymSplits.map(s => (
                <div key={s.title} className="card">
                  <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: 4 }}>{s.title}</h3>
                  <div style={{ fontSize: '0.8rem', color: 'var(--accent)', fontWeight: 600, marginBottom: 12 }}>{s.sets}</div>
                  <ul style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {s.exercises.map(e => (
                      <li key={e} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: '0.85rem', color: 'var(--text-2)' }}>
                        <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)', flexShrink: 0 }} />
                        {e}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Exercise Modal with YouTube */}
      {modal && (
        <div className="modal-overlay" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 760 }}>
            <div className="modal-header">
              <h3>{modal.icon} {modal.name}</h3>
              <button className="modal-close" onClick={() => setModal(null)}>✕</button>
            </div>
            <div className="modal-body">
              <div style={{ borderRadius: 12, overflow: 'hidden', marginBottom: 20, background: '#000', aspectRatio: '16/9' }}>
                <iframe
                  width="100%" height="100%"
                  src={`https://www.youtube.com/embed/${modal.ytId}?autoplay=1`}
                  title={modal.name}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  style={{ display: 'block', width: '100%', height: '100%' }}
                />
              </div>
              <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                {modal.tags.map(t => <span key={t} className={`tag tag-${t}`}>{t.charAt(0).toUpperCase() + t.slice(1)}</span>)}
                <span style={{ fontSize: '0.82rem', color: 'var(--text-2)', marginLeft: 'auto' }}>{modal.duration} · {modal.kcal}</span>
              </div>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-2)', lineHeight: 1.65 }}>{modal.desc}</p>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  )
}
