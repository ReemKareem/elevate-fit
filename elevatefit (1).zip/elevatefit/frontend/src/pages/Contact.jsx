import { useState } from 'react'
import { showToast } from '../components/Toast'
import Footer from '../components/Footer'

const faqs = [
  { q: 'Is Elevate Fit free?', a: 'All core features — BMI, diet, exercises, progress tracking, and chatbot — are free.' },
  { q: 'Do I need to create an account?', a: 'Public pages work without an account. Progress tracking, dashboard, and profile require signing up.' },
  { q: 'Are the diet plans suitable for Egypt?', a: 'Yes! All meal plans use Egyptian ingredients like ful, molokhia, baladi bread, karkadeh, and local vegetables.' },
  { q: 'Can I use this if I have diabetes?', a: 'The platform includes specific guidance for diabetes management. Always consult your doctor for medical decisions.' },
  { q: 'How do I cancel my account?', a: 'Go to Profile → scroll to bottom → Delete account. Your data will be permanently removed within 24 hours.' },
]

const contacts = [
  { icon: '✉️', label: 'Email', value: 'hello@elevatefit.eg' },
  { icon: '📞', label: 'Phone', value: '+20 100 123 4567' },
  { icon: '📍', label: 'Office', value: 'Cairo, Egypt' },
]

export default function Contact() {
  const [open, setOpen] = useState(0)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const send = () => {
    if (!name || !email || !message) { showToast('Please fill all fields'); return }
    showToast("Message sent! We'll get back within 24 hours ✓")
    setName(''); setEmail(''); setMessage('')
  }

  return (
    <div>
      <div className="page-wrap">
        <div className="container">
          <div className="page-hero">
            <h1>Get in <span className="accent">touch</span></h1>
            <p>We'd love to hear from you.</p>
          </div>

          {/* Contact Info Cards */}
          <div className="grid-3" style={{ marginBottom: 48 }}>
            {contacts.map(c => (
              <div key={c.label} className="card card-hover">
                <div className="icon-box" style={{ marginBottom: 14 }}>{c.icon}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-2)', marginBottom: 4 }}>{c.label}</div>
                <div style={{ fontSize: '1rem', fontWeight: 700 }}>{c.value}</div>
              </div>
            ))}
          </div>

          {/* FAQ + Form */}
          <div className="grid-2" style={{ marginBottom: 80, alignItems: 'start' }}>
            {/* FAQ */}
            <div className="card">
              <h3 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: 20 }}>FAQ</h3>
              {faqs.map((f, i) => (
                <div key={i} style={{ borderBottom: i < faqs.length - 1 ? '1px solid var(--border)' : 'none' }}>
                  <button onClick={() => setOpen(open === i ? -1 : i)} style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 0', background: 'none', border: 'none', color: 'var(--text)', fontWeight: 600, fontSize: '0.875rem', cursor: 'pointer', textAlign: 'left', fontFamily: 'var(--font)' }}>
                    {f.q}
                    <span style={{ color: open === i ? 'var(--accent)' : 'var(--text-3)', fontSize: 18, flexShrink: 0, marginLeft: 8 }}>{open === i ? '−' : '+'}</span>
                  </button>
                  {open === i && (
                    <div style={{ paddingBottom: 16, fontSize: '0.875rem', color: 'var(--text-2)', lineHeight: 1.65 }}>{f.a}</div>
                  )}
                </div>
              ))}
            </div>

            {/* Message Form */}
            <div className="card">
              <h3 style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: 20 }}>Send a message</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <div className="form-group">
                  <label className="form-label">Name</label>
                  <input className="form-input" placeholder="Your name" value={name} onChange={e => setName(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Email</label>
                  <input className="form-input" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Message</label>
                  <textarea className="form-input" rows={5} placeholder="How can we help?" value={message} onChange={e => setMessage(e.target.value)} style={{ resize: 'vertical', minHeight: 120 }} />
                </div>
                <button onClick={send} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', padding: 14 }}>Send message</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
