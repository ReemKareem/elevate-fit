import { useState } from 'react'
import Footer from '../components/Footer'

const infoCards = [
  { icon: '📊', title: 'Diabetes', text: 'Egypt ranks 9th globally for diabetes prevalence. Type 2 is largely preventable through diet, weight loss, and daily activity.' },
  { icon: '⚠️', title: 'Obesity', text: 'Nearly 4 in 10 Egyptian adults are obese. Excess fat raises risk of heart disease, stroke, fatty liver, and cancers.' },
  { icon: '❤️', title: 'Risk Factors', text: 'Sedentary lifestyle, sugary drinks, refined carbs, family history, sleep deprivation, and chronic stress all stack up.' },
  { icon: '🛡️', title: 'Prevention', text: 'Walk 7,000+ steps daily, 5 servings of vegetables, swap white rice for whole grains, and screen blood pressure & glucose yearly.' },
]

function getBMICategory(bmi) {
  if (bmi < 18.5) return { label: 'Underweight', color: '#60a5fa', tip: 'Increase calorie intake with nutrient-dense foods. Consult a nutritionist.' }
  if (bmi < 25) return { label: 'Normal Weight', color: '#c8f500', tip: 'Great work! Maintain with regular exercise and balanced Egyptian meals.' }
  if (bmi < 30) return { label: 'Overweight', color: '#f59e0b', tip: 'Aim for ~500 kcal/day deficit, add 30 min walking daily, cut sugary drinks.' }
  return { label: 'Obese', color: '#ef4444', tip: 'Consider consulting a doctor. Focus on diet and gradually increasing activity.' }
}

export default function Awareness() {
  const [height, setHeight] = useState(170)
  const [weight, setWeight] = useState(75)

  const bmi = (weight / ((height / 100) ** 2)).toFixed(1)
  const cat = getBMICategory(parseFloat(bmi))

  return (
    <div>
      <div className="page-wrap">
        <div className="container">
          {/* Hero */}
          <div className="page-hero">
            <h1>Health <span className="accent">Awareness</span></h1>
            <p>Understand the silent epidemics affecting Egypt and take the first step today.</p>
          </div>

          {/* Info Cards */}
          <div className="grid-4" style={{ marginBottom: 56 }}>
            {infoCards.map(c => (
              <div key={c.title} className="card card-hover">
                <div className="icon-box" style={{ marginBottom: 14 }}>{c.icon}</div>
                <h3 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: 8 }}>{c.title}</h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-2)', lineHeight: 1.6 }}>{c.text}</p>
              </div>
            ))}
          </div>

          {/* BMI Calculator */}
          <div className="card" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, marginBottom: 80, padding: 40 }}>
            <div>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: 6 }}>BMI Calculator</h2>
              <p style={{ color: 'var(--text-2)', fontSize: '0.875rem', marginBottom: 36 }}>Body Mass Index — a quick health screen.</p>

              {/* Height Slider */}
              <div style={{ marginBottom: 28 }}>
                <label style={{ fontSize: '0.9rem', marginBottom: 12, display: 'block' }}>
                  Height: <span style={{ color: 'var(--accent)', fontWeight: 700 }}>{height} cm</span>
                </label>
                <input type="range" min="140" max="210" value={height}
                  onChange={e => setHeight(+e.target.value)}
                  style={{ width: '100%', accentColor: 'var(--accent)', height: 4, cursor: 'pointer' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--text-3)', marginTop: 4 }}>
                  <span>140 cm</span><span>210 cm</span>
                </div>
              </div>

              {/* Weight Slider */}
              <div>
                <label style={{ fontSize: '0.9rem', marginBottom: 12, display: 'block' }}>
                  Weight: <span style={{ color: 'var(--accent)', fontWeight: 700 }}>{weight} kg</span>
                </label>
                <input type="range" min="30" max="200" value={weight}
                  onChange={e => setWeight(+e.target.value)}
                  style={{ width: '100%', accentColor: 'var(--accent)', height: 4, cursor: 'pointer' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--text-3)', marginTop: 4 }}>
                  <span>30 kg</span><span>200 kg</span>
                </div>
              </div>
            </div>

            {/* Result */}
            <div style={{ background: 'rgba(255,255,255,0.03)', border: `1px solid ${cat.color}44`, borderRadius: 'var(--radius-lg)', padding: 32, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-3)', letterSpacing: 2, marginBottom: 8, fontWeight: 600 }}>YOUR BMI</div>
              <div style={{ fontSize: '4rem', fontWeight: 900, color: 'var(--text)', lineHeight: 1, marginBottom: 8 }}>{bmi}</div>
              <div style={{ fontSize: '1.2rem', fontWeight: 700, color: cat.color, marginBottom: 16 }}>{cat.label}</div>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-2)', lineHeight: 1.6 }}>{cat.tip}</p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
