import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/')
    setOpen(false)
  }

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/awareness', label: 'Awareness' },
    { to: '/exercises', label: 'Exercises' },
    { to: '/diet', label: 'Diet Plan' },
    { to: '/progress', label: 'Progress' },
    { to: '/dashboard', label: 'Dashboard' },
    { to: '/transformation', label: 'Transformation' },
    { to: '/contact', label: 'Contact Us' },
    { to: '/profile', label: 'Profile' },
  ]

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 1000,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 32px', height: 70,
      background: 'rgba(10,10,10,0.92)', backdropFilter: 'blur(12px)',
      borderBottom: '1px solid rgba(255,255,255,0.05)'
    }}>
      {/* Logo */}
      <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 800, fontSize: '1.05rem', textDecoration: 'none', color: '#fff' }}>
        <div style={{ width: 36, height: 36, background: 'var(--accent)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>⚡</div>
        ELEVATE FIT
      </Link>

      {/* Desktop Nav */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }} className="desktop-nav">
        {navLinks.map(({ to, label }) => (
          <NavLink key={to} to={to} end={to === '/'} style={({ isActive }) => ({
            padding: '6px 11px', borderRadius: 8, fontSize: '0.82rem', fontWeight: 500,
            color: isActive ? '#fff' : '#888', background: isActive ? 'rgba(255,255,255,0.06)' : 'transparent',
            textDecoration: 'none', transition: 'all 0.2s', whiteSpace: 'nowrap'
          })}>
            {label}
          </NavLink>
        ))}
      </div>

      {/* Actions */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
        {user ? (
          <>
            <span style={{ fontSize: '0.85rem', color: '#888' }}>Hi, <strong style={{ color: '#fff' }}>{user.username}</strong></span>
            <button onClick={handleLogout} className="btn-ghost" style={{ fontSize: '0.85rem' }}>Log out</button>
          </>
        ) : (
          <>
            <Link to="/login" className="btn-ghost" style={{ fontSize: '0.85rem' }}>Log in</Link>
            <Link to="/login" className="btn btn-primary" style={{ fontSize: '0.82rem', padding: '8px 18px' }}>Get started</Link>
          </>
        )}
      </div>

      <style>{`
        @media (max-width: 1100px) { .desktop-nav { display: none !important; } }
      `}</style>
    </nav>
  )
}
