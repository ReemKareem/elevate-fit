import { useState, useEffect, useCallback } from 'react'

let showToastFn = null

export function Toast() {
  const [msg, setMsg] = useState('')
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    showToastFn = (text) => {
      setMsg(text)
      setVisible(true)
      setTimeout(() => setVisible(false), 3000)
    }
  }, [])

  return (
    <div className={`toast ${visible ? 'show' : ''}`}>{msg}</div>
  )
}

export const showToast = (msg) => showToastFn?.(msg)
