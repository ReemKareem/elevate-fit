import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-brand">
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 800, fontSize: '1.05rem' }}>
              <div style={{ width: 36, height: 36, background: 'var(--accent)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>⚡</div>
              <span style={{ color: 'var(--accent)' }}>ELEVATE FIT</span>
            </div>
            <p>Egypt's premium health platform for personalized fitness, nutrition, and lifestyle change.</p>
            <div className="footer-socials">
              <a href="#" className="social-btn">f</a>
              <a href="#" className="social-btn">𝕏</a>
              <a href="#" className="social-btn">in</a>
            </div>
          </div>

          <div className="footer-col">
            <h4>Quick Links</h4>
            <ul>
              {[['/', 'Home'], ['/awareness', 'Awareness'], ['/exercises', 'Exercises'], ['/diet', 'Diet Plan']].map(([to, label]) => (
                <li key={to}><Link to={to}>{label}</Link></li>
              ))}
            </ul>
          </div>

          <div className="footer-col">
            <h4>Resources</h4>
            <ul>
              {[['/transformation', 'Transformations'], ['/progress', 'Progress Tracker'], ['/dashboard', 'Dashboard'], ['/awareness', 'AI Chatbot']].map(([to, label]) => (
                <li key={to}><Link to={to}>{label}</Link></li>
              ))}
            </ul>
          </div>

          <div className="footer-col">
            <h4>Contact</h4>
            <div className="footer-contact">
              {[['✉', 'hello@elevatefit.eg'], ['📞', '+20 100 123 4567'], ['📍', 'Cairo, Egypt']].map(([icon, text]) => (
                <div key={text} className="footer-contact-item">
                  <span>{icon}</span><span>{text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          © 2026 Elevate Fit. All rights reserved.
        </div>
      </div>
    </footer>
  )
}
