const express = require('express')
const cors = require('cors')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const Database = require('better-sqlite3')
const path = require('path')

const app = express()
const PORT = 3001
const JWT_SECRET = 'elevatefit_secret_2026'

// DB Setup
const db = new Database(path.join(__dirname, 'elevatefit.db'))

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT,
    phone TEXT,
    gender TEXT,
    location TEXT DEFAULT 'Cairo, Egypt',
    height REAL,
    current_weight REAL,
    target_weight REAL,
    activity_level TEXT DEFAULT 'Moderate',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS progress_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    weight REAL,
    bmi REAL,
    water INTEGER,
    steps INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS contact_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`)

// Middleware
app.use(cors())
app.use(express.json())

// Auth middleware
function auth(req, res, next) {
  const header = req.headers.authorization
  if (!header) return res.status(401).json({ error: 'No token' })
  try {
    const token = header.replace('Bearer ', '')
    req.user = jwt.verify(token, JWT_SECRET)
    next()
  } catch {
    res.status(401).json({ error: 'Invalid token' })
  }
}

// ========== AUTH ROUTES ==========

// Register
app.post('/api/auth/register', async (req, res) => {
  const { email, password, username } = req.body
  if (!email || !password || !username) return res.status(400).json({ error: 'All fields required' })
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' })

  try {
    const hashed = await bcrypt.hash(password, 10)
    const stmt = db.prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)')
    const result = stmt.run(username.trim(), email.toLowerCase().trim(), hashed)
    const user = db.prepare('SELECT id, username, email, name, height, current_weight, target_weight, activity_level FROM users WHERE id = ?').get(result.lastInsertRowid)
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '30d' })
    res.json({ user, token })
  } catch (e) {
    if (e.message.includes('UNIQUE')) {
      res.status(400).json({ error: 'Email or username already exists' })
    } else {
      res.status(500).json({ error: 'Server error' })
    }
  }
})

// Login
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' })

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim())
  if (!user) return res.status(401).json({ error: 'Invalid email or password' })

  const valid = await bcrypt.compare(password, user.password)
  if (!valid) return res.status(401).json({ error: 'Invalid email or password' })

  const { password: _, ...safeUser } = user
  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '30d' })
  res.json({ user: safeUser, token })
})

// ========== USER ROUTES ==========

// Get profile
app.get('/api/user/me', auth, (req, res) => {
  const user = db.prepare('SELECT id, username, email, name, phone, gender, location, height, current_weight, target_weight, activity_level FROM users WHERE id = ?').get(req.user.id)
  res.json(user)
})

// Update profile
app.put('/api/user/profile', auth, (req, res) => {
  const { name, phone, gender, location, height, current_weight, target_weight, activity_level } = req.body
  db.prepare(`UPDATE users SET name=?, phone=?, gender=?, location=?, height=?, current_weight=?, target_weight=?, activity_level=? WHERE id=?`)
    .run(name, phone, gender, location, height ? +height : null, current_weight ? +current_weight : null, target_weight ? +target_weight : null, activity_level, req.user.id)
  const user = db.prepare('SELECT id, username, email, name, phone, gender, location, height, current_weight, target_weight, activity_level FROM users WHERE id = ?').get(req.user.id)
  res.json(user)
})

// ========== PROGRESS ROUTES ==========

// Get progress logs
app.get('/api/progress', auth, (req, res) => {
  const logs = db.prepare('SELECT * FROM progress_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 30').all(req.user.id)
  res.json(logs)
})

// Add progress log
app.post('/api/progress', auth, (req, res) => {
  const { weight, bmi, water, steps } = req.body
  const result = db.prepare('INSERT INTO progress_logs (user_id, weight, bmi, water, steps) VALUES (?, ?, ?, ?, ?)')
    .run(req.user.id, weight || null, bmi || null, water || null, steps || null)

  // Update user current weight if provided
  if (weight) db.prepare('UPDATE users SET current_weight = ? WHERE id = ?').run(weight, req.user.id)

  const log = db.prepare('SELECT * FROM progress_logs WHERE id = ?').get(result.lastInsertRowid)
  res.json(log)
})

// Delete a log
app.delete('/api/progress/:id', auth, (req, res) => {
  db.prepare('DELETE FROM progress_logs WHERE id = ? AND user_id = ?').run(+req.params.id, req.user.id)
  res.json({ success: true })
})

// ========== CONTACT ==========
app.post('/api/contact', (req, res) => {
  const { name, email, message } = req.body
  if (!name || !email || !message) return res.status(400).json({ error: 'All fields required' })
  db.prepare('INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)').run(name, email, message)
  res.json({ success: true })
})

// ========== HEALTH CHECK ==========
app.get('/api/health', (_, res) => res.json({ status: 'ok', time: new Date().toISOString() }))

app.listen(PORT, () => {
  console.log(`\n🚀 ElevateFit Backend running on http://localhost:${PORT}`)
  console.log(`📊 Database: elevatefit.db`)
  console.log(`✅ Ready!\n`)
})
